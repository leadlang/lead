# 📦 Core / Array
- 8 &'static Methods
- 0 &'a dyn Methods