# 📦 Lead Programming Language / Types
- 1 &'static Methods
- 0 &'a dyn Methods