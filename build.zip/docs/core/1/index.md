# 📦 Lead Programming Language / Core
- 6 &'static Methods
- 0 &'a dyn Methods